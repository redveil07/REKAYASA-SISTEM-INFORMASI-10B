package id.ac.ub.filkom.contoh.controller;

import id.ac.ub.filkom.contoh.service.AnggotaService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Controller: halaman lihat & tambah anggota. */
@Controller
public class AnggotaController {

    private final AnggotaService anggotaService;

    public AnggotaController(AnggotaService anggotaService) {
        this.anggotaService = anggotaService;
    }

    // GET http://localhost:8080/anggota
    @GetMapping("/anggota")
    public String lihatAnggota(Model model) {
        model.addAttribute("daftarAnggota", anggotaService.lihatSemuaAnggota());
        return "anggota";            // -> templates/anggota.html
    }

    // POST dari form tambah anggota
    @PostMapping("/anggota")
    public String tambahAnggota(@RequestParam String idAnggota,
                                @RequestParam String nama,
                                @RequestParam int batasPinjam,
                                RedirectAttributes ra) {
        boolean berhasil = anggotaService.tambahAnggota(idAnggota.trim(), nama.trim(), batasPinjam);
        if (berhasil) {
            ra.addFlashAttribute("pesan", "Anggota " + nama + " berhasil ditambahkan.");
        } else {
            ra.addFlashAttribute("error", "ID " + idAnggota + " sudah dipakai.");
        }
        return "redirect:/anggota";
    }
}