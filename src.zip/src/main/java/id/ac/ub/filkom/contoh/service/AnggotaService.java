package id.ac.ub.filkom.contoh.service;

import id.ac.ub.filkom.contoh.entity.Anggota;
import id.ac.ub.filkom.contoh.repository.AnggotaRepository;
import org.springframework.stereotype.Service;

import java.util.List;

/** Service: logika untuk fitur anggota. */
@Service
public class AnggotaService {

    private final AnggotaRepository anggotaRepository;

    public AnggotaService(AnggotaRepository anggotaRepository) {
        this.anggotaRepository = anggotaRepository;
    }

    public List<Anggota> lihatSemuaAnggota() {
        return anggotaRepository.findAll();
    }

    /** Tambah anggota baru. Return false kalau ID sudah dipakai. */
    public boolean tambahAnggota(String idAnggota, String nama, int batasPinjam) {
        if (anggotaRepository.existsById(idAnggota)) {
            return false;
        }
        anggotaRepository.save(new Anggota(idAnggota, nama, batasPinjam));
        return true;
    }
}